/**
 * @brief Envoie un SMS au numéro de téléphone prédéfini.
 * @param message Le texte du message à envoyer.
 */
void envoi_reponse(String message) {
  // Effacement des messages
  SIM800.println("AT+CMGDA=\"DEL ALL\""); // Supprime tous les messages SMS
  updateSerial();

  // Envoi du message
  SIM800.println("AT+CMGF=1"); // Met le mode SMS en TEXTE
  updateSerial();
  SIM800.println("AT+CSCS=\"GSM\""); // Définit le jeu de caractères GSM
  updateSerial();
  SIM800.println("AT+CMGS=\"" + telephone + "\""); // Prépare l'envoi au numéro de téléphone spécifié
  delay(1000); // Attend une seconde
  SIM800.println(message); // Envoie le contenu du message
  delay(500); // Attend un peu
  SIM800.write(26); // Envoie le caractère de fin de transmission (Ctrl+Z)
  updateSerial();
}

/**
 * @brief Met à jour le moniteur série avec la réponse du module SIM800L.
 * Cette fonction est utilisée pour le débogage.
 */
void updateSerial() {
  delay(1000);
  while (SIM800.available()) {
    Serial.write(SIM800.read()); // Affiche les données reçues du SIM800 sur le moniteur série de l'Arduino
  }
}
