#include <Wire.h> // Pour la communication I2C, utilisée par l'écran LCD.
#include <HardwareSerial.h> // Pour la communication série matérielle, utilisée par le PZEM et le SIM800.
#include <PZEM004Tv30.h> // Bibliothèque pour le capteur de puissance PZEM-004T.
#include <LiquidCrystal_I2C.h> // Bibliothèque pour les écrans LCD I2C.
#include <SD.h> // Bibliothèque pour la carte SD (les fonctions sont présentes mais non utilisées).
#include <SPI.h> // Pour la communication SPI, utilisée par la carte SD.
#include "time.h" // Pour la synchronisation de l'heure (utilisée pour l'horodatage).
#include <EEPROM.h> // Bibliothèque pour la mémoire EEPROM de l'ESP32.

#define EEPROM_SIZE 40 // Définit la taille de l'EEPROM à utiliser pour le stockage des données.

// Définitions des broches (pins) de la carte SD (non utilisées dans la boucle principale)
#define SD_SCK 18
#define SD_MISO 19
#define SD_MOSI 23
#define SD_CS 5

// Définitions des broches pour les composants principaux
#define prix_kWh 100.0 // Le prix du kWh (unité de référence)
#define LED_VERTE 12 // Broche de la LED Verte
#define LED_JAUNE 13 // Broche de la LED Jaune
#define LED_ROUGE 14 // Broche de la LED Rouge
#define RELAIS 27 // Broche pour le contrôle du relais
#define delais_enregistrement 10000 // Délai entre les enregistrements de données (10 secondes)

// Variables globales
bool relaisState = false; // État du relais (non utilisée directement, mais déclarée)
float tension = 0.0; // Valeur de la tension (V)
float courant = 0.0; // Valeur du courant (A)
float puissance = 0.0; // Valeur de la puissance (W)
float energie = 0.0; // Énergie totale cumulée (kWh)
float E = 0.0; // Variable temporaire pour stocker la valeur d'énergie précédente
float cos_phi = 0.9; // Facteur de puissance
boolean top = 1; // Flag pour l'envoi d'un seul SMS d'alerte (1 = à envoyer, 0 = déjà envoyé)
boolean efface = 0; // Flag pour l'effacement des messages SMS (non utilisé)
boolean COMMAND_RELAIS = 1; // Commande pour le contrôle du relais (1 = ON, 0 = OFF)
String telephone = "+2290145130091"; // Numéro de téléphone du propriétaire
String doc = "document_compteur"; // Nom du fichier pour la carte SD (non utilisé)
String document = "/" + doc + ".txt"; // Chemin complet du fichier (non utilisé)

// Initialisation des objets matériels
LiquidCrystal_I2C lcd(0x27, 20, 4); // Objet pour l'écran LCD I2C, adresse 0x27, 20 colonnes, 4 lignes.
HardwareSerial PZEMSerial(1); // Port série 1 pour le PZEM (pins RXD=2, TXD=4).
PZEM004Tv30 pzem(&Serial1, 2, 4); // Objet PZEM, utilise le port série 1.
HardwareSerial SIM800(2); // Port série 2 pour le SIM800L (pins RXD=16, TXD=17).

// Variables pour le calcul de l'énergie restante
float kWh_restant = 20.0; // kWh restants (valeur par défaut)
float kWh_recharge = 0.0; // Montant de la dernière recharge en kWh
float kWh_ref = 0.0; // Valeur de référence (dernière recharge)
float frequence = 0.0; // Fréquence du réseau électrique (Hz)

// Variables de temps
const long gmtOffset_sec = 3600; // Décalage GMT en secondes (1 heure pour WAT)
const int daylightOffset_sec = 3600; // Décalage d'heure d'été en secondes
String date = ""; // Chaîne pour stocker la date et l'heure
long time_millis = 0; // Stocke le dernier temps d'enregistrement des données

/**
 * @brief Fonction de configuration initiale du programme.
 * Cette fonction est exécutée une seule fois au démarrage.
 */
void setup() {
  // Configuration des broches
  pinMode(LED_VERTE, OUTPUT);
  pinMode(LED_JAUNE, OUTPUT);
  pinMode(LED_ROUGE, OUTPUT);
  pinMode(RELAIS, OUTPUT);
  digitalWrite(RELAIS, LOW); // Le relais est initialement désactivé.

  // Initialisation des modules
  EEPROM.begin(EEPROM_SIZE); // Initialise l'EEPROM.
  Wire.begin(); // Démarre l'I2C.
  lcd.init(); // Initialise l'écran LCD.
  lcd.backlight(); // Allume le rétroéclairage.

  Serial.begin(9600); // Démarre la communication série pour le débogage.
  SIM800.begin(9600, SERIAL_8N1, 16, 17); // Démarre le port série pour le SIM800.
  PZEMSerial.begin(9600, SERIAL_8N1, 2, 4); // Démarre le port série pour le PZEM.

  // Affichage initial sur l'écran LCD
  lcd.clear();
  lcd.setCursor(1, 0);
  lcd.print("Initialisation");
  lcd.setCursor(1, 1);
  lcd.print("du systeme...");
  delay(3000);

  Serial.println("Initialisation du module SIM800L...");

  // Configuration du module SIM800L par commandes AT
  SIM800.println("AT"); // Test de liaison
  updateSerial();
  SIM800.println("AT+CMGF=1"); // Mode SMS en TEXTE
  updateSerial();
  SIM800.println("AT+CNMI=2,1,0,0,0"); // Affiche les nouveaux SMS directement sur le port série.
  updateSerial();
  SIM800.println("AT+CLTS=1"); // Active le fuseau horaire local (pour la fonction AT+CCLK?).
  updateSerial();

  // Les fonctions de carte SD sont commentées
  /* SPI.begin(SD_SCK, SD_MISO, SD_MOSI, SD_CS); ... */

  // Récupération des valeurs sauvegardées en EEPROM
  repereValues(); // Récupère les valeurs de kWh_restant, kWh_recharge et kWh_ref.
  //stockeValues(); // Fonction de sauvegarde, non appelée au démarrage.

  lcd.clear();
  E = energie; // Initialise la variable E avec l'énergie actuelle.

  // Lecture initiale des données du PZEM
  tension = checkNaN(pzem.voltage());
  courant = checkNaN(pzem.current());
  puissance = checkNaN(pzem.power());
  energie = checkNaN(pzem.energy());
  cos_phi = checkNaN(pzem.pf());
  frequence = checkNaN(pzem.frequency());
  delay(1000);
}

/**
 * @brief Boucle principale du programme.
 * Cette fonction s'exécute en continu après la configuration.
 */
void loop() {
  // Enregistrement des données et mise à jour de la base de données
  if ((millis() - time_millis) >= 60000) { // Si 60 secondes se sont écoulées
    if (courant > 0) { // Si une consommation est détectée
      stockeValues(); // Sauvegarde les valeurs dans l'EEPROM
      handleData(); // Envoie les données à Firebase
    }
    time_millis = millis(); // Réinitialise le compteur
  }

  // Lecture des données du PZEM
  tension = checkNaN(pzem.voltage());
  courant = checkNaN(pzem.current());
  puissance = checkNaN(pzem.power());
  energie = checkNaN(pzem.energy());
  cos_phi = checkNaN(pzem.pf());
  frequence = checkNaN(pzem.frequency());

  // Affichage des données sur l'écran LCD
  lcd.setCursor(0, 0); lcd.print(tension); lcd.setCursor(7, 0); lcd.print("V");
  lcd.setCursor(10, 0); lcd.print(courant); lcd.setCursor(17, 0); lcd.print("A");
  lcd.setCursor(0, 1); lcd.print(puissance); lcd.setCursor(7, 1); lcd.print("W");
  lcd.setCursor(10, 1); lcd.print(energie, 4); lcd.setCursor(17, 1); lcd.print("kWh");
  lcd.setCursor(0, 2); lcd.print(cos_phi); lcd.setCursor(7, 2); lcd.print("PF");
  lcd.setCursor(10, 2); lcd.print(frequence); lcd.setCursor(17, 2); lcd.print("Hz");
  lcd.setCursor(0, 3); lcd.print(kWh_restant, 4); lcd.setCursor(7, 3); lcd.print("kWh (r)");

  traiterMessage(); // Traite les messages SMS entrants

  // Logique de contrôle du relais et des LED
  if (COMMAND_RELAIS == 1) { // Si la commande du relais est active
    if (kWh_restant <= 0) { // S'il ne reste plus de kWh
      digitalWrite(LED_ROUGE, HIGH);
      digitalWrite(LED_VERTE, LOW);
      digitalWrite(LED_JAUNE, LOW);
      digitalWrite(RELAIS, LOW); // Coupe le courant
      if (top == 1) {
        envoi_reponse("Votre rechargement est epuise"); // Envoie un SMS d'alerte
        top = 0; // Désactive le flag pour ne pas envoyer le SMS à nouveau
      }
    } else { // S'il reste des kWh
      // Vérifie si les kWh restants sont inférieurs à 20% de la dernière recharge
      if (100 * (kWh_restant / kWh_ref) < 20 && kWh_ref > 0) {
        digitalWrite(LED_ROUGE, LOW);
        digitalWrite(LED_VERTE, LOW);
        digitalWrite(LED_JAUNE, HIGH); // LED jaune : alerte
        digitalWrite(RELAIS, HIGH); // Maintient le courant
        if (top == 1) {
          envoi_reponse("Vous avez atteint 80% de votre derniere recharge et le kWh restant est " + String(kWh_restant) + "");
          top = 0;
        }
        kWh_restant = kWh_restant - (energie - E); // Met à jour les kWh restants
        E = energie;
      } else { // Si le niveau est supérieur à 20%
        digitalWrite(RELAIS, HIGH);
        digitalWrite(LED_ROUGE, LOW);
        digitalWrite(LED_VERTE, HIGH); // LED verte : normal
        digitalWrite(LED_JAUNE, LOW);
        kWh_restant = kWh_restant - (energie - E); // Met à jour les kWh restants
        E = energie;
      }
    }
  }
}

/**
 * @brief Formate les données des capteurs en JSON et les envoie.
 */
void handleData() {
  String da = getDateAndTime(); // Récupère la date et l'heure
  String dos = "{";
  dos += "\"date\":\"" + da + "\",";
  dos += "\"tension\":\"" + String(tension, 4) + "\",";
  dos += "\"courant\":\"" + String(courant, 4) + "\",";
  dos += "\"kWh restant\":\"" + String(kWh_restant, 4) + "\",";
  dos += "\"cosphi\":\"" + String(cos_phi, 4) + "\",";
  dos += "\"puissance\":\"" + String(puissance, 4) + "\",";
  dos += "\"energie\":\"" + String(energie, 4) + "\"";
  dos += "}";
  envoi_donnees(dos); // Appelle la fonction pour envoyer les données
}

/**
 * @brief Récupère l'heure et la date depuis le module SIM800.
 * @return Une chaîne de caractères contenant la date et l'heure.
 */
String getDateAndTime() {
  SIM800.println("AT+CCLK?"); // Demande l'heure au module
  delay(1000);
  String responseTime = "";
  while (SIM800.available()) {
    char c = SIM800.read();
    responseTime += c;
  }
  // Extraction des valeurs de la réponse AT+CCLK
  int startIndex = responseTime.indexOf("\"");
  int endIndex = responseTime.indexOf("\"", startIndex + 1);
  if (startIndex != -1 && endIndex != -1) {
    String dateTime = responseTime.substring(startIndex + 1, endIndex);
    String year = dateTime.substring(0, 2);
    String month = dateTime.substring(3, 5);
    String day = dateTime.substring(6, 8);
    String hour = dateTime.substring(9, 11);
    String minute = dateTime.substring(12, 14);
    return year + "/" + month + "/" + day + "," + hour + ":" + minute;
  }
  return "";
}

/**
 * @brief Vérifie si une valeur est NaN et la remplace par 0.0 si c'est le cas.
 * @param value La valeur à vérifier.
 * @return La valeur originale ou 0.0 si elle était NaN.
 */
float checkNaN(float value) {
  if (isnan(value)) {
    Serial.println("Valeur NaN détectée, remplacement par 0.0");
    return 0.0;
  } else {
    Serial.print("Valeur: ");
    Serial.println(value);
    return value;
  }
}

/**
 * @brief Sauvegarde les valeurs sur une carte SD (fonction non utilisée).
 * Note : Cette fonction est présente mais n'est pas appelée dans la boucle principale.
 */
void STOCKER() { /* ... */ }

/**
 * @brief Récupère les valeurs depuis une carte SD (fonction non utilisée).
 * Note : Cette fonction est présente mais n'est pas appelée dans la boucle principale.
 */
void RECUPERER(String file_nam) { /* ... */ }
