#include <EEPROM.h> // Inclusion de la bibliothèque EEPROM (déjà inclus dans le fichier principal, mais bonne pratique)

/**
 * @brief Lit et traite les messages SMS reçus.
 * Si un message commence par "montant=", il extrait le montant pour recharger le compteur.
 */
void traiterMessage() {
  while (SIM800.available()) { // Tant qu'il y a des données sur le port série du SIM800
    String sms = SIM800.readString(); // Lit le message entrant
    if (sms.indexOf("+CMGR:") != -1) { // Vérifie si c'est une notification de nouveau message
      String messageContent = sms.substring(sms.indexOf("\n") + 1); // Extrait le contenu du message
      messageContent.trim(); // Supprime les espaces avant et après
      Serial.print("Message recu: ");
      Serial.println(messageContent);

      if (messageContent.startsWith("montant=")) { // Si le message commence par "montant="
        recupererMontant(messageContent); // Appelle la fonction pour extraire le montant
      } else {
        envoi_reponse("votre message est mal ecrit, le format est 'montant=valeur'"); // Répond avec un message d'erreur
      }

      SIM800.println("AT+CMGDA=\"DEL ALL\""); // Efface tous les messages pour éviter de les traiter plusieurs fois
      updateSerial();
    }
  }
}

/**
 * @brief Extrait un montant d'une chaîne de caractères et met à jour les variables du compteur.
 * @param message La chaîne de caractères contenant le message de recharge.
 */
void recupererMontant(String message) {
  int egalIndex = message.indexOf('='); // Cherche la position du signe "="
  if (egalIndex != -1) {
    String montantString = message.substring(egalIndex + 1); // Extrait la partie après le "="
    float montant = montantString.toFloat(); // Convertit la chaîne en nombre décimal

    if (montant > 0) { // Si le montant est valide et supérieur à 0
      kWh_restant += montant; // Ajoute le montant aux kWh restants
      kWh_recharge = montant; // Met à jour la dernière recharge
      kWh_ref = kWh_restant; // Met à jour la valeur de référence
      stockeValues(); // Sauvegarde les nouvelles valeurs dans l'EEPROM
      top = 1; // Réactive le flag d'alerte pour les prochains cycles
      String reponse = "Votre compteur a ete recharge de " + String(montant) + " kWh. Votre nouveau solde est de " + String(kWh_restant) + " kWh.";
      envoi_reponse(reponse); // Envoie un SMS de confirmation
      Serial.println(reponse);
    } else {
      envoi_reponse("Le montant de rechargement est invalide.");
      Serial.println("Le montant de rechargement est invalide.");
    }
  } else {
    envoi_reponse("Format de message de rechargement invalide.");
    Serial.println("Format de message de rechargement invalide.");
  }
}
