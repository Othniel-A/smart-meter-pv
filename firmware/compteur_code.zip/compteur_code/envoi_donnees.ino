// Déclaration des fonctions (prototypes)
void envoi_donnees(String data); // Fonction principale pour l'envoi de données
void post_to_firebase(String data); // Envoie une requête POST à Firebase
void gprs_connect(); // Établit une connexion GPRS
boolean is_gprs_connected(); // Vérifie l'état de la connexion GPRS
boolean waitResponse(String expected_answer = "OK", unsigned int timeout = 2000); // Attend une réponse spécifique d'une commande AT

// Constantes pour la connexion GPRS
const String APN = "moov"; // Nom du point d'accès de votre opérateur
const String USER = "moovweb"; // Nom d'utilisateur GPRS
const String PASS = "moov"; // Mot de passe GPRS

// Constantes pour Firebase
const String FIREBASE_HOST = "https://compteur-intelligent-69cbe-default-rtdb.firebaseio.com/consoEnTempsReel/compteurID_1"; // L'URL de votre base de données Firebase
const String FIREBASE_SECRET = "UV9KIitao84GqdBI23BZN4XlPF3LdyvgKfUq13RS"; // Le secret de votre base de données pour l'authentification

#define USE_SSL true // Active ou désactive l'utilisation de SSL/TLS (HTTPS)
#define DELAY_MS 500 // Délai par défaut en millisecondes

/**
 * @brief Fonction principale pour envoyer des données.
 * @param data La chaîne de caractères JSON à envoyer.
 */
void envoi_donnees(String data) {
  Serial.println("Initializing SIM800...");
  Serial.println(data);
  if (!is_gprs_connected()) { // Vérifie si la connexion GPRS est active
    gprs_connect(); // Si non, se connecte
  }
  post_to_firebase(data); // Envoie la requête POST
  SIM800.println("AT+SAPBR=0,1"); // Désactive le contexte GPRS
  updateSerial();
}

/**
 * @brief Envoie les données à Firebase via une requête HTTP POST.
 * Cette fonction utilise des commandes AT pour configurer et envoyer la requête.
 * @param data La chaîne de caractères JSON des données à envoyer.
 */
void post_to_firebase(String data) {
  // Initialisation du service HTTP
  SIM800.println("AT+HTTPINIT");
  updateSerial();
  if (USE_SSL == true) { // Active SSL si nécessaire
    SIM800.println("AT+HTTPSSL=1");
    updateSerial();
  }
  // Configuration des paramètres HTTP
  SIM800.println("AT+HTTPPARA=\"CID\",1");
  updateSerial();
  // Configuration de l'URL avec le secret d'authentification
  SIM800.println("AT+HTTPPARA=\"URL\"," + FIREBASE_HOST + ".json?auth=" + FIREBASE_SECRET);
  updateSerial();
  SIM800.println("AT+HTTPPARA=\"REDIR\",1"); // Active la redirection
  updateSerial();
  SIM800.println("AT+HTTPPARA=\"CONTENT\",\"application/json\""); // Définit le type de contenu comme JSON
  updateSerial();
  // Préparation de l'envoi des données
  SIM800.println("AT+HTTPDATA=" + String(data.length()) + ",10000"); // Spécifie la taille des données
  updateSerial();
  SIM800.println(data); // Envoie la chaîne de caractères JSON
  updateSerial();
  delay(1500);
  // Exécution de la requête POST
  SIM800.println("AT+HTTPACTION=1");
  updateSerial();
  delay(4500); // Délai pour attendre la réponse de la requête
  // Arrêt du service HTTP
  SIM800.println("AT+HTTPREAD");
  updateSerial();
  SIM800.println("AT+HTTPTERM");
  updateSerial();
}

/**
 * @brief Connecte le module SIM800L au réseau GPRS.
 */
void gprs_connect() {
  Serial.println("Connecting to GPRS...");
  SIM800.println("AT+SAPBR=3,1,\"Contype\",\"GPRS\""); // Configure le type de connexion
  waitResponse("OK");
  SIM800.println("AT+SAPBR=3,1,\"APN\",\"" + APN + "\""); // Configure l'APN
  waitResponse("OK");
  SIM800.println("AT+SAPBR=3,1,\"USER\",\"" + USER + "\""); // Configure l'utilisateur
  waitResponse("OK");
  SIM800.println("AT+SAPBR=3,1,\"PWD\",\"" + PASS + "\""); // Configure le mot de passe
  waitResponse("OK");
  SIM800.println("AT+SAPBR=1,1"); // Active le contexte GPRS
  waitResponse("OK");
  delay(2000);
}

/**
 * @brief Vérifie si le GPRS est connecté.
 * @return 'true' si connecté, 'false' sinon.
 */
boolean is_gprs_connected() {
  SIM800.println("AT+SAPBR=2,1"); // Demande l'état du GPRS
  delay(3000);
  String response = "";
  while (SIM800.available()) {
    response += (char)SIM800.read();
  }
  Serial.println(response);
  return response.indexOf("1,1") != -1; // Cherche l'état "1,1" (connecté)
}

/**
 * @brief Attend une réponse spécifique du module SIM800.
 * @param expected_answer La réponse attendue (par défaut "OK").
 * @param timeout Le délai d'attente en millisecondes.
 * @return 'true' si la réponse est reçue, 'false' sinon.
 */
boolean waitResponse(String expected_answer, unsigned int timeout) {
  unsigned long t = millis();
  String response = "";
  boolean is_timeout = true;
  while (t + timeout > millis()) {
    while (SIM800.available()) {
      char c = SIM800.read();
      response += c;
    }
    if (response.indexOf(expected_answer) > -1) { // Vérifie si la réponse contient la chaîne attendue
      is_timeout = false;
      break;
    }
  }
  Serial.println(response);
  return is_timeout;
}
