#include <EEPROM.h> // Inclusion de la bibliothèque EEPROM

/**
 * @brief Sauvegarde les variables importantes dans la mémoire EEPROM.
 * Les valeurs sont stockées séquentiellement.
 */
void stockeValues() {
  EEPROM.writeFloat(0, kWh_restant); // Sauvegarde kWh_restant à l'adresse 0
  EEPROM.writeFloat(4, kWh_recharge); // Sauvegarde kWh_recharge à l'adresse 4 (chaque float prend 4 octets)
  EEPROM.writeFloat(8, kWh_ref); // Sauvegarde kWh_ref à l'adresse 8
  EEPROM.commit(); // Écrit les données en mémoire de manière permanente
}

/**
 * @brief Récupère les variables importantes depuis la mémoire EEPROM.
 * Les valeurs sont lues aux mêmes adresses que celles où elles ont été sauvegardées.
 */
void repereValues() {
  kWh_restant = EEPROM.readFloat(0); // Lit kWh_restant à l'adresse 
  kWh_recharge = EEPROM.readFloat(4); // Lit kWh_recharge à l'adresse 4
  kWh_ref = EEPROM.readFloat(8); // Lit kWh_ref à l'adresse 8
}
